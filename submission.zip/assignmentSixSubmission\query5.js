const { MongoClient } = require("mongodb");
const { createClient } = require("redis");

const MONGO_URI = "mongodb://localhost:27017";
const MONGO_DB = "ieeevisTweets";

async function main() {
  const mongo = new MongoClient(MONGO_URI);
  await mongo.connect();
  const db = mongo.db(MONGO_DB);
  const tweetsCollection = db.collection("Tweets_Only");
  const usersCollection = db.collection("users");

  const redis = createClient();
  redis.on("error", (err) => console.error("Redis Client Error:", err));
  await redis.connect();

  const allUsers = await usersCollection.find({}).toArray();
  const userMap = {};
  for (const user of allUsers) {
    userMap[user.id.toString()] = user.screen_name;
  }

  const allTweets = await tweetsCollection.find({}).toArray();

  for (const tweet of allTweets) {
    const screenName = userMap[tweet.user_id?.toString()];
    const tweetId = tweet.id_str || tweet.id?.toString();

    if (screenName && tweetId) {
      await redis.rPush(`tweets:${screenName}`, tweetId);

      await redis.hSet(`tweet:${tweetId}`, {
        user_name: screenName,
        text: tweet.text || "",
        created_at: tweet.created_at || "",
        retweet_count: (tweet.retweet_count || 0).toString(),
        favorite_count: (tweet.favorite_count || 0).toString(),
      });
    }
  }

  await mongo.close();
  await redis.quit();
}

main().catch(console.error);