const { MongoClient } = require("mongodb");
const { createClient } = require("redis");

const MONGO_URI = "mongodb://localhost:27017";
const MONGO_DB = "ieeevisTweets";
const MONGO_COLLECTION = "Tweets_Only";

async function main() {
  const mongo = new MongoClient(MONGO_URI);
  await mongo.connect();
  const db = mongo.db(MONGO_DB);
  const tweetsCollection = db.collection(MONGO_COLLECTION);

  const redis = createClient();
  redis.on("error", (err) => console.error("Redis Client Error:", err));
  await redis.connect();

  await redis.set("favoritesSum", 0);

  const allTweets = await tweetsCollection.find({}).toArray();
  for (const tweet of allTweets) {
    const favCount = tweet.favorite_count || 0;
    if (favCount > 0) {
      await redis.incrBy("favoritesSum", favCount);
    }
  }

  const favoritesSum = await redis.get("favoritesSum");
  console.log(`Total number of favorites: ${favoritesSum}`);

  await mongo.close();
  await redis.quit();
}

main().catch(console.error);