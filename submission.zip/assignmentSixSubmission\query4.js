const { MongoClient } = require("mongodb");
const { createClient } = require("redis");

const MONGO_URI = "mongodb://localhost:27017";
const MONGO_DB = "ieeevisTweets";

async function main() {
  const mongo = new MongoClient(MONGO_URI);
  await mongo.connect();
  const db = mongo.db(MONGO_DB);
  const tweetsCollection = db.collection("Tweets_Only");
  const usersCollection = db.collection("users");

  const redis = createClient();
  redis.on("error", (err) => console.error("Redis Client Error:", err));
  await redis.connect();

  const allUsers = await usersCollection.find({}).toArray();
  const userMap = {};
  for (const user of allUsers) {
    userMap[user.id.toString()] = user.screen_name;
  }

  const allTweets = await tweetsCollection.find({}).toArray();
  for (const tweet of allTweets) {
    const screenName = userMap[tweet.user_id?.toString()];
    if (screenName) {
      await redis.zIncrBy("leaderboard", 1, screenName);
    }
  }

  const top10 = await redis.zRangeWithScores("leaderboard", 0, 9, {
    REV: true,
  });

  console.log("Top 10 Users Leaderboard:");
  top10.forEach((entry, index) => {
    console.log(`${index + 1}. ${entry.value}: ${entry.score} tweets`);
  });

  await mongo.close();
  await redis.quit();
}

main().catch(console.error);